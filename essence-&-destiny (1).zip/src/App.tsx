/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence, useMotionValue, useTransform } from 'motion/react';
import { 
  Heart, 
  Sparkles, 
  Moon, 
  Star, 
  Palette, 
  Calendar, 
  User, 
  ChevronRight, 
  History,
  Compass,
  Zap,
  Coffee,
  Cloud,
  Flower2,
  Camera,
  Music,
  Plane,
  Cake
} from 'lucide-react';

// --- Types ---
type GameState = 'WELCOME' | 'LIKES' | 'COLOR' | 'VITAL' | 'NAME' | 'CALCULATING' | 'REVEAL';

interface FormData {
  likes: string[];
  color: string;
  age: string;
  zodiac: string;
  firstName: string;
  lastName: string;
}

const LIKES_OPTIONS = [
  { id: 'coffee', label: 'Cozy Cafes', icon: Coffee, description: 'The smell of roasted beans and warm corners.' },
  { id: 'music', label: 'Live Music', icon: Music, description: 'Feeling the rhythm in a crowded room.' },
  { id: 'travel', label: 'New Adventures', icon: Plane, description: 'Exploring hidden streets in a far-off city.' },
  { id: 'nature', label: 'Morning Walks', icon: Flower2, description: 'The soft light hitting the dew on the grass.' },
  { id: 'art', label: 'Museum Dates', icon: Palette, description: 'Finding meaning in colors and quiet halls.' },
  { id: 'photos', label: 'Capturing Moments', icon: Camera, description: 'Freezing a beautiful smile forever.' },
  { id: 'dreams', label: 'Star Gazing', icon: Moon, description: 'Lying in the grass, feeling small but connected.' },
  { id: 'chill', label: 'Rainy Days', icon: Cloud, description: 'The sound of droplets against the windowpane.' },
  { id: 'book', label: 'Old Books', icon: Heart, description: 'Stories that take you to a thousand worlds.' },
  { id: 'sunset', label: 'Golden Hour', icon: Star, description: 'The sky turning into a painting of fire.' },
  { id: 'dessert', label: 'Sweet Treats', icon: Cake, description: 'A little bit of sugar for a sweet soul.' },
  { id: 'hike', label: 'Mountain Tops', icon: Compass, description: 'The view from above, where air is fresh.' },
  { id: 'fire', label: 'Warm Fires', icon: Zap, description: 'The crackle of wood on a cold winter night.' },
  { id: 'garden', label: 'Secret Gardens', icon: Flower2, description: 'Blooms that only we know about.' },
  { id: 'dance', label: 'Late Night Dancing', icon: Music, description: 'Moving like nobody is watching us.' },
  { id: 'cinema', label: 'Classic Movies', icon: Camera, description: 'Black and white films on a big screen.' },
];

const COLORS = [
  { name: 'Rose', hex: '#FDA4AF' },
  { name: 'Lavender', hex: '#DDD6FE' },
  { name: 'Sky', hex: '#BAE6FD' },
  { name: 'Gold', hex: '#FDE68A' },
  { name: 'Sage', hex: '#D1FAE5' },
  { name: 'Cream', hex: '#FEF3C7' },
];

const ZODIACS = [
  'Aries', 'Taurus', 'Gemini', 'Cancer', 
  'Leo', 'Virgo', 'Libra', 'Scorpio', 
  'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'
];

// --- Components ---

const SwipeCard = ({ 
  item, 
  onSwipe, 
  index 
}: { 
  item: typeof LIKES_OPTIONS[0], 
  onSwipe: (dir: 'left' | 'right') => void, 
  index: number,
  key?: string
}) => {
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-25, 25]);
  const opacity = useTransform(x, [-200, -150, 0, 150, 200], [0, 1, 1, 1, 0]);
  const colorRight = useTransform(x, [0, 150], ['rgba(255,255,255,0)', 'rgba(52,211,153,0.2)']);
  const colorLeft = useTransform(x, [0, -150], ['rgba(255,255,255,0)', 'rgba(248,113,113,0.2)']);

  const handleDragEnd = (_: any, info: any) => {
    if (info.offset.x > 100) onSwipe('right');
    else if (info.offset.x < -100) onSwipe('left');
  };

  return (
    <motion.div
      style={{ x, rotate, opacity, zIndex: 50 - index }}
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      onDragEnd={handleDragEnd}
      className="absolute inset-0 flex items-center justify-center cursor-grab active:cursor-grabbing px-6"
    >
      <motion.div 
        className="glass-card w-full max-w-sm aspect-[3/4] rounded-3xl flex flex-col items-center justify-center p-12 text-center gap-6 relative overflow-hidden"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: index * 0.1 }}
      >
        <motion.div style={{ backgroundColor: colorRight }} className="absolute inset-y-0 right-0 w-1/2 pointer-events-none" />
        <motion.div style={{ backgroundColor: colorLeft }} className="absolute inset-y-0 left-0 w-1/2 pointer-events-none" />
        
        <div className="bg-pink-100 p-8 rounded-full">
          <item.icon className="w-16 h-16 text-pink-500" />
        </div>
        <h3 className="font-serif text-3xl font-medium tracking-tight text-gray-800">
          {item.label}
        </h3>
        <p className="text-gray-600 text-sm font-sans italic opacity-80 max-w-[80%]">
          {item.description}
        </p>
        <p className="text-gray-400 text-[10px] font-mono uppercase tracking-widest mt-4">
          Swipe right if you love this,<br />left if it's not for you.
        </p>
      </motion.div>
    </motion.div>
  );
};

export default function App() {
  const [gameState, setGameState] = useState<GameState>('WELCOME');
  const [formData, setFormData] = useState<FormData>({
    likes: [],
    color: '',
    age: '',
    zodiac: '',
    firstName: '',
    lastName: '',
  });

  const [currentLikeIndex, setCurrentLikeIndex] = useState(0);

  const nextStage = () => {
    if (gameState === 'WELCOME') setGameState('LIKES');
    else if (gameState === 'LIKES') setGameState('COLOR');
    else if (gameState === 'COLOR') setGameState('VITAL');
    else if (gameState === 'VITAL') setGameState('NAME');
    else if (gameState === 'NAME') {
      setGameState('CALCULATING');
      setTimeout(() => setGameState('REVEAL'), 4000);
    }
  };

  const handleSwipe = (direction: 'left' | 'right') => {
    if (direction === 'right') {
      setFormData(prev => ({
        ...prev,
        likes: [...prev.likes, LIKES_OPTIONS[currentLikeIndex].label]
      }));
    }
    
    if (currentLikeIndex < LIKES_OPTIONS.length - 1) {
      setCurrentLikeIndex(prev => prev + 1);
    } else {
      nextStage();
    }
  };

  return (
    <div className="min-h-screen dreamy-gradient flex flex-col items-center justify-center p-4">
      <AnimatePresence mode="wait">
        
        {/* --- WELCOME --- */}
        {gameState === 'WELCOME' && (
          <motion.div
            key="welcome"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="text-center max-w-lg space-y-8"
          >
            <div className="flex justify-center mb-6">
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
              >
                <Heart className="w-20 h-20 text-rose-400 fill-rose-100" />
              </motion.div>
            </div>
            <h1 className="font-serif text-5xl md:text-7xl font-bold tracking-tighter text-gray-900 leading-none">
              Essence <span className="italic text-rose-500">&</span> Destiny
            </h1>
            <p className="font-sans text-lg text-gray-600 leading-relaxed max-w-sm mx-auto">
              A mystical journey to uncover your true nature and the path the stars have laid for you.
            </p>
            <button
              onClick={nextStage}
              className="group relative inline-flex items-center gap-2 px-8 py-4 bg-gray-900 text-white rounded-full font-medium overflow-hidden transition-all hover:pr-10 hover:bg-gray-800"
            >
              Begin Your Journey
              <ChevronRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </button>
            <div className="pt-12 flex justify-center gap-8 opacity-30 grayscale pointer-events-none">
              <Sparkles className="w-6 h-6" />
              <Moon className="w-6 h-6" />
              <Star className="w-6 h-6" />
            </div>
          </motion.div>
        )}

        {/* --- LIKES SWIPE --- */}
        {gameState === 'LIKES' && (
          <motion.div
            key="likes"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full h-screen relative flex flex-col items-center justify-center"
          >
            <div className="absolute top-12 text-center z-10 space-y-2">
              <p className="text-rose-500 font-mono text-xs uppercase tracking-widest font-bold">Step 01 / 04</p>
              <h2 className="font-serif text-4xl text-gray-800">What resonates with you?</h2>
              <p className="text-[10px] text-gray-400 font-mono uppercase tracking-[0.2em]">
                {currentLikeIndex + 1} of {LIKES_OPTIONS.length} Elements
              </p>
            </div>
            
            <div className="relative w-full h-[60vh] max-w-sm">
              <AnimatePresence>
                {LIKES_OPTIONS.slice(currentLikeIndex, currentLikeIndex + 1).map((item) => (
                  <SwipeCard 
                    key={item.id} 
                    item={item} 
                    onSwipe={handleSwipe} 
                    index={currentLikeIndex}
                  />
                ))}
              </AnimatePresence>
            </div>

            <div className="absolute bottom-12 flex gap-12 text-gray-400 font-mono text-xs uppercase tracking-widest">
              <span className="flex items-center gap-2 animate-pulse">← Swipe No</span>
              <span className="flex items-center gap-2 animate-pulse">Swipe Yes →</span>
            </div>
          </motion.div>
        )}

        {/* --- COLOR SELECTION --- */}
        {gameState === 'COLOR' && (
          <motion.div
            key="color"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="max-w-md w-full text-center space-y-12"
          >
            <div>
              <p className="text-rose-500 font-mono text-xs uppercase tracking-widest mb-2 font-bold font-sans">Step 02 / 04</p>
              <h2 className="font-serif text-4xl text-gray-800">What color defines your aura?</h2>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              {COLORS.map((c) => (
                <button
                  key={c.name}
                  onClick={() => {
                    setFormData(prev => ({ ...prev, color: c.name }));
                    nextStage();
                  }}
                  className="glass-card group p-6 rounded-2xl flex flex-col items-center gap-4 transition-all hover:scale-105 active:scale-95"
                >
                  <div 
                    className="w-16 h-16 rounded-full shadow-inner transition-transform group-hover:scale-110" 
                    style={{ backgroundColor: c.hex }} 
                  />
                  <span className="font-sans font-medium text-gray-600">{c.name}</span>
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {/* --- VITAL INFO (AGE/ZODIAC) --- */}
        {gameState === 'VITAL' && (
          <motion.div
            key="vital"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            className="max-w-md w-full glass-card p-10 rounded-[2.5rem] space-y-10"
          >
            <div className="text-center">
              <p className="text-rose-500 font-mono text-xs uppercase tracking-widest mb-2 font-bold font-sans">Step 03 / 04</p>
              <h2 className="font-serif text-4xl text-gray-800">Celestial Alignment</h2>
            </div>

            <div className="space-y-8">
              <div className="space-y-4">
                <label className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-gray-400 font-bold">
                  <History className="w-4 h-4" /> Your Age
                </label>
                <input 
                  type="number" 
                  placeholder="How many orbits around the sun?"
                  className="w-full bg-white/50 border-b-2 border-gray-100 py-3 text-2xl font-serif focus:outline-none focus:border-rose-300 transition-colors"
                  value={formData.age}
                  onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
                />
              </div>

              <div className="space-y-4">
                <label className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-gray-400 font-bold">
                  <Compass className="w-4 h-4" /> Your Sign
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {ZODIACS.map(z => (
                    <button
                      key={z}
                      onClick={() => setFormData(prev => ({ ...prev, zodiac: z }))}
                      className={`py-2 text-xs rounded-lg border transition-all ${
                        formData.zodiac === z 
                          ? 'bg-gray-900 text-white border-gray-900' 
                          : 'bg-white/50 text-gray-600 border-gray-100 hover:border-rose-200'
                      }`}
                    >
                      {z}
                    </button>
                  ))}
                </div>
              </div>

              <button
                disabled={!formData.age || !formData.zodiac}
                onClick={nextStage}
                className="w-full py-4 bg-gray-900 text-white rounded-2xl font-medium disabled:opacity-30 disabled:cursor-not-allowed transition-all hover:bg-gray-800"
              >
                Proceed to Final Reveal
              </button>
            </div>
          </motion.div>
        )}

        {/* --- IDENTITY CHECK --- */}
        {gameState === 'NAME' && (
          <motion.div
            key="name"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="max-w-md w-full glass-card p-10 rounded-[2.5rem] space-y-10"
          >
            <div className="text-center">
              <p className="text-rose-500 font-mono text-xs uppercase tracking-widest mb-2 font-bold font-sans">Final Step</p>
              <h2 className="font-serif text-4xl text-gray-800">Who shall I address?</h2>
              <p className="text-sm text-gray-500 mt-2">The stars need names for a perfect alignment.</p>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <input 
                  type="text" 
                  placeholder="First Name"
                  className="w-full bg-white/50 border-b-2 border-gray-100 py-3 text-2xl font-serif focus:outline-none focus:border-rose-300 transition-colors"
                  value={formData.firstName}
                  onChange={(e) => setFormData(prev => ({ ...prev, firstName: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <input 
                  type="text" 
                  placeholder="Family Name"
                  className="w-full bg-white/50 border-b-2 border-gray-100 py-3 text-2xl font-serif focus:outline-none focus:border-rose-300 transition-colors"
                  value={formData.lastName}
                  onChange={(e) => setFormData(prev => ({ ...prev, lastName: e.target.value }))}
                />
              </div>

              <button
                disabled={!formData.firstName || !formData.lastName}
                onClick={nextStage}
                className="w-full py-4 bg-gray-900 text-white rounded-2xl font-medium disabled:opacity-30 transition-all hover:bg-gray-800 flex items-center justify-center gap-2"
              >
                Calculate My Destiny
                <Zap className="w-4 h-4 fill-white" />
              </button>
            </div>
          </motion.div>
        )}

        {/* --- CALCULATING --- */}
        {gameState === 'CALCULATING' && (
          <motion.div
            key="calc"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-center space-y-8"
          >
            <div className="relative">
              <motion.div 
                className="w-32 h-32 border-4 border-rose-200 rounded-full mx-auto"
                animate={{ rotate: 360 }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              />
              <motion.div 
                className="absolute inset-0 flex items-center justify-center"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                <Sparkles className="w-12 h-12 text-rose-500" />
              </motion.div>
            </div>
            <div className="space-y-2">
              <h2 className="font-serif text-3xl text-gray-800 italic">Reading the threads of existence...</h2>
              <div className="flex justify-center gap-2 text-rose-400">
                <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ repeat: Infinity, delay: 0 }}>Collecting memories...</motion.span>
                <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ repeat: Infinity, delay: 0.5 }}>Tracing your aura...</motion.span>
                <motion.span animate={{ opacity: [0, 1, 0] }} transition={{ repeat: Infinity, delay: 1 }}>Seeing the future...</motion.span>
              </div>
            </div>
          </motion.div>
        )}

        {/* --- THE TRICK REVEAL --- */}
        {gameState === 'REVEAL' && (
          <motion.div
            key="reveal"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-2xl w-full text-center space-y-12 pb-20"
          >
            <motion.div
              animate={{ 
                y: [0, -10, 0],
                filter: ["drop-shadow(0 0 0px #f43f5e)", "drop-shadow(0 0 20px #fb7185)", "drop-shadow(0 0 0px #f43f5e)"] 
              }}
              transition={{ duration: 4, repeat: Infinity }}
              className="inline-block"
            >
              <Heart className="w-24 h-24 text-rose-500 fill-rose-500" />
            </motion.div>

            <div className="space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
              >
                <p className="font-mono text-xs uppercase tracking-[0.3em] text-rose-500 font-bold mb-4">The Verdict</p>
                <h1 className="font-serif text-5xl md:text-7xl font-bold text-gray-900 leading-tight">
                  What are you, <span className="text-rose-600 italic">{formData.firstName}</span>?
                </h1>
              </motion.div>

              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.5 }}
                className="font-sans text-2xl text-gray-700 leading-relaxed max-w-xl mx-auto"
              >
                After analyzing your love for {formData.likes.slice(0, 3).join(', ')}{formData.likes.length > 3 ? ' and more' : ''}, 
                your {formData.color} aura, and the celestial position of {formData.zodiac}...
                The truth is simple.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 3, type: "spring" }}
                className="glass-card p-12 rounded-[3.5rem] bg-white/60 relative overflow-hidden"
              >
                 <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-rose-400 to-transparent" />
                 <h2 className="font-serif text-4xl md:text-6xl font-black text-rose-600 mb-8 italic">
                   "You are the best thing that ever happened to me."
                 </h2>
                 <p className="font-sans text-xl text-gray-600">
                    You're not just a combination of likes or signs.<br />
                    You are the love of my life, my {formData.color} sky in a grey world.
                 </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 5 }}
                className="mt-16 space-y-4"
              >
                <p className="font-mono text-xs uppercase tracking-[0.3em] text-gray-400 font-bold">The Future</p>
                <div className="flex flex-col gap-4">
                  <div className="flex items-center justify-center gap-4">
                    <div className="h-[1px] w-12 bg-gray-300" />
                    <Sparkles className="w-5 h-5 text-gray-400" />
                    <div className="h-[1px] w-12 bg-gray-300" />
                  </div>
                  <p className="font-serif text-3xl italic text-gray-800">
                    "A destiny written by us, starting with a 100% chance of forever."
                  </p>
                </div>
              </motion.div>

              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 7 }}
                onClick={() => window.location.reload()}
                className="mt-12 text-gray-400 hover:text-rose-500 transition-colors font-mono text-xs uppercase flex items-center justify-center gap-2 mx-auto"
              >
                <History className="w-4 h-4" /> Start Over
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Background elements */}
      <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
        <motion.div 
          animate={{ x: [0, 100, 0], y: [0, 50, 0] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute -top-40 -left-40 w-96 h-96 bg-rose-200 rounded-full blur-[100px] opacity-20"
        />
        <motion.div 
          animate={{ x: [0, -50, 0], y: [0, 100, 0] }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          className="absolute -bottom-40 -right-40 w-96 h-96 bg-purple-200 rounded-full blur-[100px] opacity-20"
        />
      </div>
    </div>
  );
}
